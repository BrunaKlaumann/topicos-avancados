﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConFinServer.Models
{
    public class Estado
    {
        public string est_sigla { get; set; }
        public string nome { get; set; }
    }
}
