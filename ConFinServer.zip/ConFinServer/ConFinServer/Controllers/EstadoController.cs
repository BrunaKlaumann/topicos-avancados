﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ConFinServer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ConFinServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoController : ControllerBase
    {
        public static List<Estado> lista = new List<Estado>();
          
        [AcceptVerbs("GET")]
        public List<Estado> Get()
        {
            return lista;
        }

        [AcceptVerbs("POST")]
        public void Post(Estado estado)
        {
            lista.Add(estado);
        }
    }
}