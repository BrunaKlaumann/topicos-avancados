﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ConFinServer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ConFinServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoController : ControllerBase
    {
        public static List<Estado> lista = new List<Estado>();
          
        [AcceptVerbs("GET")]
        public List<Estado> Get()
        {
            return lista;
        }


        [AcceptVerbs("POST")]
        public string PostEstado(Estado estado)
        {
            lista.Add(estado);
            return "Estado incluido com sucesso";
        }

        [AcceptVerbs("PUT")]
        public string PutEstado(Estado estado)
        {
            lista.Where(l => l.est_sigla == estado.est_sigla)
                .Select(o => { o.nome = estado.nome; return o; })
                .ToList();

            return "Estado alterado com sucesso: ";
        }

        [AcceptVerbs("DELETE")]
        public string DeleteEstado (Estado estado)
        {
            Estado auxestado = lista.Where(l => l.est_sigla == estado.est_sigla)
                .Select(o => o)
                .First();
            lista.Remove(auxestado);
            return "Estado excluido com sucesso!";
        }
    }
}